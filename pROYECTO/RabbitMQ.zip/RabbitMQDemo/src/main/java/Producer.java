import com.rabbitmq.client.*;
public class Producer {
     private final static String QUEUE_NAME = "test_queue";

    public static void main(String[] argv) throws Exception {
        // Crear conexión y canal
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");  // Asegúrate de que RabbitMQ esté corriendo localmente
        try (Connection connection = factory.newConnection(); 
             Channel channel = connection.createChannel()) {
            
            // Declarar una cola
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
            
            // Crear el mensaje
            String message = "HOLAAAAAAA!";
            String message2 = "Somos el equipo 3";
            String message3 = "SE VE?";

            
            // Enviar el mensaje
            channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
            System.out.println(" Producer envio '" + message + "'");
            
              channel.basicPublish("", QUEUE_NAME, null, message2.getBytes());
            System.out.println("Producer envió: '" + message2 + "'");
            
              channel.basicPublish("", QUEUE_NAME, null, message3.getBytes());
            System.out.println("Producer envió: '" + message3 + "'");
            
        }
    }
    
}
