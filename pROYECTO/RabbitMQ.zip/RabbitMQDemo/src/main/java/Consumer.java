import com.rabbitmq.client.*;
public class Consumer {
      private final static String QUEUE_NAME = "test_queue";

    public static void main(String[] argv) throws Exception {
        // Crear conexión y canal
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");  // Asegúrate de que RabbitMQ esté corriendo localmente
        try (Connection connection = factory.newConnection(); 
             Channel channel = connection.createChannel()) {
            
            // Declarar la cola
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
            
            System.out.println(" Esperando los mensajes");
            
            // Crear un consumidor
            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String message = new String(delivery.getBody(), "UTF-8");
                System.out.println(" Consumer recibio'" + message + "'");
              
            };
            
            // Consumir los mensajes
            channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> { });
        }
    }
}
